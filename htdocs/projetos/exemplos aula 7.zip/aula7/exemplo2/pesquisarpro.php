<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
</head>
<body>
	<form method="POST" action="pesquisarpro.php">
		Nome do Produto: <input type="text" name="produto" maxlength="30" placeholder="digite o nome">
		<input type="submit" value="pesquisar" name="botao">
	</form>

	<?php 
	if(isset($_POST["botao"])){

		require("conecta.php");
		$produto=htmlentities($_POST["produto"]);

			// gravando dados
		$query = $mysqli->query("select * from tb_produtos where produto like '%$produto%'");
		echo $mysqli->error;

		echo "
		<table border='1' width='400'>
		<tr>
		<th>ID</th>
		<th>Produto</th>
		<th>Preço</th>
		</tr>
		";
		while ($tabela=$query->fetch_assoc()) {
			echo "
			<tr><td align='center'>$tabela[idpro]</td>
			<td align='center'>$tabela[produto]</td>
			<td align='center'>$tabela[preco]</td>
			</tr>
			";
		}
		echo "</table>";

	}
	?>
	<a href='index.php'> Voltar</a>
</body>
</html>

