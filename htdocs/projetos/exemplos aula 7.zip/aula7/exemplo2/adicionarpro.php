<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
</head>
<body>
	<form method="POST" action="adicionarpro.php">
		Nome do Produto: <input type="text" name="produto" maxlength="30" placeholder="digite o produto">
		<br/><br/>
		Preço do Produto: <input type="text" name="preco" maxlength="15" placeholder="digite o preço">		
		<input type="submit" value="salvar" name="botao">
	</form>

</body>
</html>

<?php 
if(isset($_POST["botao"])){

	require("conecta.php");

	//$nome=$_POST["nome"];
	$produto=htmlentities($_POST["produto"]);	
	$preco=htmlentities($_POST["preco"]);

	// gravando dados
	$mysqli->query("insert into tb_produtos values('', '$produto', '$preco')");
	echo $mysqli->error;

	if($mysqli->error == ""){

		echo "<br />Inserido com sucesso<br /></br />";

		echo "<a href='index.php'> Voltar</a>";
	}

}
?>