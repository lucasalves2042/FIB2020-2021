<?php 
require("conecta.php");

$produto="";
$preco=""; 
if(isset($_GET["alterar"])){

	$idpro = htmlentities($_GET["alterar"]);
	$query=$mysqli->query("select * from tb_produtos where idpro = '$idpro'");
	$tabela=$query->fetch_assoc();
	$produto=$tabela["produto"];		
	$preco=$tabela["preco"];
}

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
</head>
<body>
	<form method="POST" action="alterarpro.php">
		<input type="hidden" name="idpro" value="<?php echo $idpro ?>">
		Nome do Produto: <input type="text" name="produto" value="<?php echo $produto ?>">
		<br/><br/>			
		Preço do Produto: <input type="text" name="preco" value="<?php echo $preco ?>">
		<input type="submit" value="Salvar" name="botao">

	</form>
	<a href ="index.php"> Voltar </a>
	<br />
</body>
</html>


<?php 
if(isset($_POST["botao"])){

	$idpro   = htmlentities($_POST["idpro"]);
	$produto = htmlentities($_POST["produto"]);
	$preco   = htmlentities($_POST["preco"]);

	$mysqli->query("update tb_produtos set produto = '$produto', preco='$preco' where idpro = '$idpro'  ");
	echo $mysqli->error;
	if ($mysqli->error == "") {
		echo "Alterado com sucesso";
	}
}

?>