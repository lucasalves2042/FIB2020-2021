<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<title>Cadastros</title>
</head>
<body>
	<h2>Cadastros</h2>
	<div><a href="cadcli.php">Clientes</a></div>
	<div><a href="cadpro.php">Produtos</a></div>	
</body>
</html>